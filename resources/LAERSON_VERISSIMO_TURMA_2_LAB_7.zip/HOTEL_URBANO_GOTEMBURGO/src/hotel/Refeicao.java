package hotel;

public interface Refeicao {
	public double getPreco();

}
