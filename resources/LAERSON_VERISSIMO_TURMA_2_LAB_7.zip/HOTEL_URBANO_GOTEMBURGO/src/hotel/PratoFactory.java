package hotel;

public enum PratoFactory implements RefeicaoFactory {
	PRATO_FACTORY;

	@Override
	public Refeicao createRefeicao() {
		// TODO Auto-generated method stub
		return null;
	}

}
