package hotel;

public interface RefeicaoFactory {
	public Refeicao createRefeicao();

}
