package hotel;

public enum QuartoType implements QuartoState {
	QUARTO_PRESIDENCIAL {
		@Override
		public double getDiaria() {
			// TODO Auto-generated method stub
			return 0;
		}
	},
	QUARTO_LUXO {
		@Override
		public double getDiaria() {
			// TODO Auto-generated method stub
			return 0;
		}
	},
	QUARTO_SIMPLES {
		@Override
		public double getDiaria() {
			// TODO Auto-generated method stub
			return 0;
		}
	};

}
