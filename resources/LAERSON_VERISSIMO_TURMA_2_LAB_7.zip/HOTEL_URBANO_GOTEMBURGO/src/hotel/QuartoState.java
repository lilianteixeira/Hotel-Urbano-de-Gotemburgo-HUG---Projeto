package hotel;

public interface QuartoState {
	double getDiaria();

}
