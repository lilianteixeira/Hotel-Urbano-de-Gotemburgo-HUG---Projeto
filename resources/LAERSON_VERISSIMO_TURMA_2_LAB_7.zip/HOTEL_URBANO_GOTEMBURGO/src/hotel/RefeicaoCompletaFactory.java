package hotel;

public enum RefeicaoCompletaFactory implements RefeicaoFactory {
	REFEICAO_FACTORY;

	@Override
	public Refeicao createRefeicao() {
		// TODO Auto-generated method stub
		return null;
	}

}
