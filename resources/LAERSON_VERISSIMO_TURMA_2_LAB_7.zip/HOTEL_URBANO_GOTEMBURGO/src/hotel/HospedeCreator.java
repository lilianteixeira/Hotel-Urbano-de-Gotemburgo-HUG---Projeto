package hotel;

public enum HospedeCreator {
	//Na uml está CREATOR
	HOSPEDE_CREATOR;
	
	public Hospede createHospede(String nome, String email, int anoDeNascimento) {
		//A partir das informações dadas, esse método deve retornar um hospede
		return null;
	}

}
