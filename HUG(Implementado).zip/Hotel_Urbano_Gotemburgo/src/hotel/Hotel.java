package hotel;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import cadastro.*;

public class Hotel {
	private CadastroSet cadastros;
	private EstadiaMap estadias;
	private RegistroSet registros;
	private QuartoSet quartos;

	public Hotel() {
		this.cadastros = new CadastroSet();
		this.estadias = new EstadiaMap();
		this.registros = new RegistroSet();
		this.quartos = new QuartoSet();
	}

	public boolean cadastraHospede(String nome, String email, String dataDeNascimento) {
		cadastros.addCadastro(CadastroFactory.INSTANCE.create(nome, email, dataDeNascimento));
		return true;
	}

	public boolean removeCadastro(String email) {
		return cadastros.removeCadastro(cadastros.buscaCadastro(email));
	}

	public void checkIn(String email, String id, int dias) {
		Cadastro hospede = cadastros.buscaCadastro(email);
		Quarto quarto = quartos.buscaQuarto(id);
		Estadia estadia = EstadiaFactory.INSTANCE.create(quarto, dias);
		estadias.putEstadia(estadia, hospede);
		quarto.setOcupadoState(); // Muda o estado do quarto pra ocupado
	}

	public void checkOut(String email) {
		Cadastro hospede = cadastros.buscaCadastro(email);
		Set<Map.Entry<Estadia, Cadastro>> entradas = estadias.entrySet();
		Iterator<Map.Entry<Estadia, Cadastro>> i = entradas.iterator();
		Map.Entry<Estadia, Cadastro> entrada;

		while (i.hasNext()) {// Varre todas as estadias
			entrada = i.next();
			if (entrada.getValue().equals(hospede)) {
				// se a estadia estiver relacionada ao email que está fazendo
				// checkout...
				registros.addRegistro(RegistroFactory.INSTANCE.create(hospede.getNome(), entrada.getKey().getId(),
						entrada.getKey().getPrecoTotal()));// esse trecho cria
															// uma instância de
															// RegistroCheckOut
															// com as
															// informações da
															// estadia, e
															// adiciona à lista
															// de registros
				quartos.buscaQuarto(entrada.getKey().getId()).setOcupadoState(); // Esse
																					// trecho
																					// muda
																					// o
																					// quarto
																					// para
																					// desocupado
				entradas.remove(entrada);// Esse trecho remove a estadia da
											// lista de estadias.
			}
		}
	}
}
